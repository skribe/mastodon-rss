This is the first release of the Wordpress plugin.  It's not available on the Wordpress site and probably never will be.

It's very basic.

To use:

1. Install by uploading as you would any other wordpress plugin.
2. Activate plugin
3. Go to Appearance->Widgets
4. Add widget to the preferred location.  It's called Mastodon RSS Widget (you'll probably need to search for it)
5. In the widget settings include the RSS feed from Mastodon (it needs to be from Mastodon otherwise it won't work)
6. Update
7. It works! (hopefully).
